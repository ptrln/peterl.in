// This file was provided by the CS175 HW3/HW4 solutions.
#ifndef MODEL_3D_H
#define MODEL_3D_H

#include <stdlib.h>
#include <vector>
#include "vpmath.h"

// fwd decl
class objLoader;
class Material;
class GeometryList;

/* note that all features aren't implemented for OBJ support, just those necessary
   for the landspeeder model, e.g., only quad meshes; should be easy to generalize */

class Model3D{
public:	
	Model3D() : ready(false),loader(NULL), geometry(NULL), materials(NULL){}
	void loadOBJ(const char *filename);
	~Model3D();
	void render();
	bool intersects(Model3D *otherModel) const;
private:
	void cleanup();
	bool ready;
	objLoader *loader;
	Material **materials;
	GeometryList ***geometry;

	int nm;
};

class GeometryList{
public:
	GeometryList(objLoader *loader, int materialIndex, int vertsPerFace,Material *material);
	GeometryList();
	void render();
	~GeometryList();
	int vertsPerFace, materialIndex, numFaces;

private:
	bool hasTexture,hasColor;
	Point *vertexData;
	Vector *texCoordData;
	Vector *colorData;
	Vector *normalData;
};

#endif