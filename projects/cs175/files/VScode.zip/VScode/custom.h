class Laser { 
	
public:
	float or[3];
	float destination[3];
	float loc[3];
	bool isEnemy;
	int step;
	float distance;
	float angle1;
	float angle2;
	float col[3];
	// Constructor 
	Laser(float,float,float,float ds1, float ds2, float ds3,bool ie) ; 
	// Destructor 
	~Laser(){} ; 
	
	
	void Move() ; 
	void enemyMove();
}; 

class Unit {
public:
	int step;
	float scale;
	float trans[3];
	float rotate[3];
	float offset[3];
	float loc[3];
	int unitX;
	int hp;
	int maxhp;
	void* model;
	int renderState;
	float radius;
	float center[3];
	int fireChance;
	int fireLag;
	bool exploded;

	Unit(void* mo ,float scl,
			float tr1, float tr2, float tr3,
			float ro1, float ro2, float ro3,
			float x, float y, float z,
			int uX,int hp1, float rd, int);
	~Unit(){};

	void animate();
	void setCenter(float, float, float);
	bool testCollision(float, float, float);
};

class Explosion{
public:
	int type;
	int step;
	float x,y,z;
	Explosion(int i,float x1, float y1, float z1){type=i;step=0;x=x1;y=y1;z=z1;};
	~Explosion(){};
};