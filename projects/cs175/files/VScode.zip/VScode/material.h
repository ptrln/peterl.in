// This file was provided by the CS175 HW3/HW4 solutions.
#ifndef MATERIAL_H
#define MATERIAL_H

#define GLEW_STATIC
#include <GL/glew.h>
#ifdef __MAC__
#	include <GLUT/glut.h>
#else
#  define FREEGLUT_STATIC
#  include <GL/glut.h>
#endif

#include <string>

/* note: texture format must be tga, 8-bit/channel */ 

// fwd decl
struct obj_material;

#define MATERIAL_TEXTURE_UNIT        GL_TEXTURE0

class Material{
public:
	// fixme: need to know which texture to assign it
	// texIndex is the texture unit index
	Material(obj_material *objMaterial);
	Material(const char *textureFilename);
	~Material();
	void activate();
	void deactivate();

private:

	// texture info
	bool hasTex;
	GLuint texHandle;
	GLint texWidth,texHeight,texComp;
	GLenum texFormat;

	// phong parameters
	float ambient[3];
	float diffuse[3];
	float specular[3];
	float specPower;

	// transparency
	float trans;
};

#endif