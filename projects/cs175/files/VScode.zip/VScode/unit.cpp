#include "custom.h"
#include "model3d.h"

Unit::Unit(void* mo,float scl,
			float tr1, float tr2, float tr3,
			float ro1, float ro2, float ro3,
			float x, float y, float z,
			int uX,int hp1, float rd, int fc) {
	model = mo;
	scale=scl;
	hp=maxhp=hp1;
	unitX=uX;
	trans[0]=tr1;
	trans[1]=tr2;
	trans[2]=tr3;
	loc[0]=tr1+x;
	loc[1]=tr2+y;
	loc[2]=tr3+z;
	rotate[0]=ro1;
	rotate[1]=ro2;
	rotate[2]=ro3;
	radius = rd;
	renderState = 200;
	center[0]=tr1;
	center[1]=tr2;
	center[2]=tr3;
	offset[0]=x;
	offset[1]=y;
	offset[2]=z;
	fireChance = fc;
	fireLag=5;
	exploded=false;
}

void Unit::animate(){
	if (renderState>100){
		loc[0]=trans[0]+offset[0]*(1.0-(200.0-renderState)/100.0);
		loc[1]=trans[1]+offset[1]*(1.0-(200.0-renderState)/100.0);
		loc[2]=trans[2]+offset[2]*(1.0-(200.0-renderState)/100.0);
	} else if (renderState<100){
		loc[1]-=0.02;
	}
	renderState--;
}

void Unit::setCenter(float x, float y, float z){
	center[0]=x;
	center[1]=y;
	center[2]=z;
}

bool Unit::testCollision(float x, float y, float z){

	float distance = sqrt(pow(center[0]-x,2)+pow(center[1]-y,2)+pow(center[2]-z,2));

	if (distance<=radius){
		hp-=(radius-distance)/radius*50;
		if (hp<=0)
			renderState--;
		return true;
	}
	return false;
}