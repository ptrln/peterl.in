#include "custom.h"
#include <cmath>

Laser::Laser(float or1, float or2, float or3,float ds1, float ds2, float ds3,bool ie) {
	or[0] = or1;
	or[1]=or2;
	or[2]=or3;
	destination[0]=ds1;
	destination[1]=ds2;
	destination[2]=ds3;
	isEnemy=ie;
	step=5;
	loc[0] = or1;
	loc[1] = or2;
	loc[2] = or3;

	distance = sqrt(sqrt((pow(or1-ds1,2)+pow(or2-ds2,2)+pow(or3-ds3,2))));

   angle1 = angle2 = atan2(abs(or1-ds1), abs(or2-ds2)) * 180.0/ 3.14159;

   angle1 = angle1 *log(distance) *0.8;

   if (ds1<or1){
	   angle1=-angle1;
   }

   if (ds1>or1){
	   angle2=-angle2;
   }
}

void Laser::Move() {

	loc[0] = or[0] + destination[0]*step/100.0;
	loc[1] = or[1] + destination[1]*step/100.0;
	loc[2] = or[2] + destination[2]*step/100.0;
	
	step+=10/distance;
} 

void Laser::enemyMove(){
	loc[0] = or[0] + ((-or[0])+destination[0])*step/100.0;
	loc[1] = or[1] + ((-or[1])+destination[1])*step/100.0;
	loc[2] = or[2] + ((-or[2])+destination[2])*step/100.0;
	
	step++;
	step++;
}