////////////////////////////////////////////////////////////////////////
//
//   Harvard Computer Science
//	  CS 175: Introduction to Computer Graphics
//   Professor: Hanspeter Pfister
//   TFs: Moritz Baecher, Yuanchen Zhu, Kalyan Sunkavalli, Kevin Dale
//
//   File: main.cpp
//   Name: Peter Lin
//   Date: 11/05/2010
//   Desc: Final Project for CS175. Implemenation of a Starwars themed
//         shooter game. This file was partially provided by the CS175 
//		   HW3/HW4 skeleton code and solutions.
//   
////////////////////////////////////////////////////////////////////////

// I N C L U D E S /////////////////////////////////////////////////////

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <vector>
#include <iostream>
#include <fstream>
#include <string>
#include <windows.h>
#include <mmsystem.h>
#include <conio.h>

#define GLEW_STATIC
#include <GL/glew.h>
#ifdef __MAC__
#	include <GLUT/glut.h>
#else
#  define FREEGLUT_STATIC
#  include <GL/glut.h>
#endif

#include "GLTools.h"

#include "shaders.h"

#include "Camera.h"

#include "objLoader.h"

#include "model3d.h"
#include "custom.h"

using namespace std;



// CONSTANTS
// ----------------------------------------------------------------------------------------------------

// initial screen dimensions
static const int INIT_SCREEN_WIDTH = 800;
static const int INIT_SCREEN_HEIGHT = 400;

// projection parameters
static const float FOV = 45.0f;
static const float FAR_PLANE = 0.01f;
static const float NEAR_PLANE = 100.0f;



// ----------------------------------------------------------------------------------------------------

// GLOBALS
// ----------------------------------------------------------------------------------------------------

// camera parameters
Camera cam;
static float camInitCenter[] = { 0.0f, 1.0f, 0.0f };	// init camera center / eye vector
static float camInitUp[] = { 0.0f, 0.0f, 1.0f };		// init up vector 
static float camInitLook[] ={ 0.0f, 0.0f, 0.0f };		// init scene center
static float camRoll = 0.0f;
static float camPitch = 0.0f;
static float camYaw = 0.0f;

// projection, view and model matrices
static float fmProj[16];
static float fmView[16];
static float fmModel[16];

// shader parameters 
float fvLightWorldCoords[] = {0.0f, -10.0f,20.0f};
static float fvAmbient[] = {0.8f, 0.8f, 0.8f, 1.0f};
static float fvDiffuse[] = {0.5f, 0.5f, 0.5f, 1.0f};
static float fvSpecular[] = {0.1f, 0.1f, 0.1f, 1.0f};
static float fSpecularPower[] = {25.0};
static float fvBaseColor[] = {1.0f, 1.0f, 1.0f, 1.0f};

// flags
bool drawClouds = false;
enum DrawMode { DRAW_PHONG, DRAW_COLOR_MAP, DRAW_BUMP_MAP } activeDrawMode = DRAW_BUMP_MAP;
bool drawSkyBox = true;

// global variables
int mouseX, mouseY, sceneN = 0, sequence = 0, delay = 33, shipX = 400, shipDX = 0, 
	battleN = 0, fireLag = 0, screenX=800, screenY=400, shieldLeft=3, shieldTimeRemaining, 
	shieldLag=300, playerHP=300;

bool moveable = false, mousefire = false, initUnits[10], drawBounds=false, useShield = false, 
	 gameOver=false, gameBeat=false, explodeSound=false, devMode = false;

GLuint vboId;                              // ID of VBO

float topo[512][1024], terSca = 0.05f, loc[3], boundRadius=0.3, landOffset=0, diffMulti=1.0;
double pos[3];

vector<Laser> laserVec;
vector<Laser> enemyLaserVec;
vector<Unit> unitVec;
vector<Explosion> expVec;
Model3D landspeeder,deathStar,yt1300,enemy,jedi,trifighter,nothing;

// ----------------------------------------------------------------------------------------------------

// HELPER FUNCTIONS
// ----------------------------------------------------------------------------------------------------

// Checks if there's an error inside OpenGL and if yes,
// print the error the throw an exception.
// This function was provided by the CS175 HW3/HW4 solutions.
void checkGLErrors() {
	const GLenum errCode = glGetError();      // check for errors
	if (errCode != GL_NO_ERROR) {
		std::cerr << "Error: " << gluErrorString(errCode) << std::endl;
		throw runtime_error((const char*)gluErrorString(errCode));
	}
}



// ----------------------------------------------------------------------------------------------------

// SHADER HANDLING
// ----------------------------------------------------------------------------------------------------

// number of shaders

static const int NUM_SHADERS = 5;

// shader program handles
GLuint shaderProgramHandles[ NUM_SHADERS ];

// constants for shaders
enum Shaders { SHADER_PHONG, SHADER_COLOR_MAP, SHADER_BUMP_MAP, SHADER_CLOUD_MAP, SHADER_SKYBOX };

// file names for shaders
static const char *shaderProgramFileNames[NUM_SHADERS][2] = {  {"phong.vert", "phong.frag"},
                                                               {"colormap.vert", "colormap.frag"}, 
                                                               {"bumpmap.vert", "bumpmap.frag"}, 
                                                               {"cloudmap.vert", "cloudmap.frag"}, 
                                                               {"skybox.vert", "skybox.frag"}};

// ----------------------------------------------------------------------------------------------------

// TEXTURE MAPPING
// ----------------------------------------------------------------------------------------------------
// number of textures
static const int NUM_TEXTURES = 18;

// texture handles
GLuint textureHandles[ NUM_TEXTURES ];

// constants for textures
enum Textures {   TEXTURE_EARTH_COLOR_MAP, TEXTURE_EARTH_NORMAL_MAP, 
                  TEXTURE_EARTH_CLOUD_MAP, TEXTURE_EARTH_CLOUD_TRANS_MAP, 
                  TEXTURE_MOON_COLOR_MAP, TEXTURE_MOON_NORMAL_MAP, 
                  TEXTURE_SUN_COLOR_MAP, TEXTURE_MARS_TOPO_MAP,
				  TEXTURE_MARS_COLOR_MAP, TEXTURE_MARS_NORMAL_MAP,
					TEXTURE_SWLOGO, TEXTURE_SWCRAWL ,
					TEXTURE_SWLOGOT, TEXTURE_SWCRAWLT,
					TEXTURE_SWGG,TEXTURE_SWBEAT, TEXTURE_SWBEATT, TEXTURE_SWGGT};

// file names for textures
const char *textureFileNames[ NUM_TEXTURES ] = {   ".//planets//earth//earth_colormap_4k.tga", 
                                                   ".//planets//earth//earth_normalmap_4k.tga", 
                                                   ".//planets//earth//earth_cloudmap.tga", 
                                                   ".//planets//earth//earth_cloudtransmap.tga",
                                                   ".//planets//moon//moon_colormap_4k.tga", 
                                                   ".//planets//moon//moon_normalmap_4k.tga", 
                                                   ".//planets//sun//sun_colormap.tga",
												   ".//mars_1k_topo.tga",
												   ".//mars_1k_color.tga",
												   ".//mars_1k_normal.tga" ,
													".//Textures//swlogo.tga",
													".//Textures//swcrawl.tga",	
													".//Textures//swlogot.tga",
													".//Textures//swcrawlt.tga",
													".//Textures//swgg.tga",
													".//Textures//swbeat.tga",
													".//Textures//swbeatt.tga",
													".//Textures//swggt.tga"};

// This function was provided by the CS175 HW3/HW4 solutions.
void loadTextures( )
{
   
   // get number of texture units
   GLint numTextureUnits;
   glGetIntegerv( GL_MAX_TEXTURE_IMAGE_UNITS, &numTextureUnits );
   cout << "There are " << numTextureUnits << " texture units available." << endl; 

   // create texture handles for texture objects
   glGenTextures( NUM_TEXTURES, textureHandles );
   
   for( int textureIndex = 0; textureIndex < NUM_TEXTURES; textureIndex++ )
   {
      // bind texture object to texture handle
      glBindTexture( GL_TEXTURE_2D, textureHandles[ textureIndex ] );
      
      // load texture object from file into CPU memory
      GLbyte *pTextureData;
      GLint textureWidth, textureHeight, textureComponents;
      GLenum textureFormat;
      
      // use a GLTools library function to read the pixel data from the .tga files
      pTextureData = gltReadTGABits( textureFileNames[ textureIndex ], &textureWidth, &textureHeight, &textureComponents, &textureFormat );
      assert( pTextureData != NULL );
      cout << "Texture " << textureFileNames[ textureIndex ] << " loaded. W: " << textureWidth << " H: " << textureHeight << " C: " << textureComponents << " F: " << textureFormat << endl;
	 
	 

	  if (textureIndex==7)
	  {
		  cout << pTextureData[513]+0 << " " << pTextureData[1025]+0 << " " << pTextureData[2]+0 << " ";
		  int p = 0;
		  for (int i=0;i<512;i++)
			  for (int j=0;j<1024;j++)
				topo[i][j] = ((float)pTextureData[p++]);		
	  }
	  else 
	  {
		
      // set minification filter
      GLenum minFilter = GL_LINEAR_MIPMAP_LINEAR;
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minFilter);
      

      // set magnification filter
      GLenum magFilter = GL_LINEAR;
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magFilter);
      
      
      // set texture wrap modes
      GLenum wrapMode = GL_REPEAT;
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrapMode);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrapMode);
      
      // load texture object into GPU memory
      glTexImage2D( GL_TEXTURE_2D, 0, textureComponents, textureWidth, textureHeight, 0, textureFormat, GL_UNSIGNED_BYTE, pTextureData );
      /*if(minFilter == GL_LINEAR_MIPMAP_LINEAR || 
         minFilter == GL_LINEAR_MIPMAP_NEAREST ||
         minFilter == GL_NEAREST_MIPMAP_LINEAR ||
         minFilter == GL_NEAREST_MIPMAP_NEAREST)
         glGenerateMipmap(GL_TEXTURE_2D);*/

      // generate mipmaps
      glGenerateMipmap( GL_TEXTURE_2D );
	  }
      // free memory for texture object in CPU memory
      free( pTextureData );
	  
   }
   checkGLErrors();
}

// number of cube textures
// 6 (one for each side of the cube)
static const int NUM_CUBE_TEXTURES = 6;

GLuint cubeTextureHandle;

GLenum  cube[6] = {  GL_TEXTURE_CUBE_MAP_POSITIVE_X,
                     GL_TEXTURE_CUBE_MAP_NEGATIVE_X,
                     GL_TEXTURE_CUBE_MAP_POSITIVE_Y,
                     GL_TEXTURE_CUBE_MAP_NEGATIVE_Y,
                     GL_TEXTURE_CUBE_MAP_POSITIVE_Z,
                     GL_TEXTURE_CUBE_MAP_NEGATIVE_Z };


const char *cubeTextureFileNames[ NUM_CUBE_TEXTURES ] = {  ".//planets//skybox//stars_pos_x.tga", 
                                                           ".//planets//skybox//stars_neg_x.tga", 
                                                           ".//planets//skybox//stars_pos_y.tga", 
                                                           ".//planets//skybox//stars_neg_y.tga", 
                                                           ".//planets//skybox//stars_pos_z.tga", 
                                                           ".//planets//skybox//stars_neg_z.tga" };

// This function was provided by the CS175 HW3/HW4 solutions.
void loadCubeMap() 
{
   GLbyte *pTextureData;
   GLint textureWidth, textureHeight, textureComponents;
   GLenum textureFormat;

   // create texture handle for cube map
   glGenTextures( 1, &cubeTextureHandle );
   
   // bind texture object to texture handle
   glBindTexture( GL_TEXTURE_CUBE_MAP, cubeTextureHandle );
   
   // set texture filter
   GLenum minFilter = GL_LINEAR;
   glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, minFilter);
   GLenum magFilter = GL_LINEAR;
   glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, magFilter);
   // set texture wrap modes
   GLenum wrapMode = GL_CLAMP_TO_EDGE;
   glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, wrapMode);
   glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, wrapMode);
   glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, wrapMode);       

   glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
   

   // Load Cube Map images
   for( int cubeTextureIndex = 0; cubeTextureIndex < NUM_CUBE_TEXTURES; cubeTextureIndex++ )
   { 
      // use a GLTools library function to read the pixel data from the .tga files
      pTextureData = gltReadTGABits( cubeTextureFileNames[ cubeTextureIndex ], &textureWidth, &textureHeight, &textureComponents, &textureFormat );
      assert( pTextureData != NULL );
      cout << "Texture " << cubeTextureFileNames[ cubeTextureIndex ] << " loaded. Width: " << textureWidth << " H: " << textureHeight << " C: " << textureComponents << " F: " << textureFormat << endl;

      // load texture object into GPU memory
      glTexImage2D( cube[ cubeTextureIndex ], 0, textureComponents, textureWidth, textureHeight, 0, textureFormat, GL_UNSIGNED_BYTE, pTextureData );
      
      // free CPU memory
      free(pTextureData);
      
   }
   glGenerateMipmap(GL_TEXTURE_CUBE_MAP);
   checkGLErrors();
}

// This function was provided by the CS175 HW3/HW4 solutions.
void deleteTextures()
{
   // free memory for texture objects on GPU
   glDeleteTextures( NUM_TEXTURES, textureHandles );
   glDeleteTextures( 1, &cubeTextureHandle );
}


// ----------------------------------------------------------------------------------------------------

// RENDERING
// ----------------------------------------------------------------------------------------------------

void createTerrain(){
	GLfloat* buffer = new GLfloat[1023*511*4*3+1023*511*4*2]; // create vertex array
	
	// generate a new VBO and get the associated ID
	glGenBuffersARB(1, &vboId);

	int p=0;

	for (int i=0;i<512-1;i++){
		 for (int j=0;j<1024-1;j++){
			 // quad 0
			 buffer[p++] = j*terSca;// x
			 buffer[p++] = topo[i][j]*terSca/5;//y
			 buffer[p++]= i*terSca;// z
			 
			 // quad 1
			 buffer[p++] = (j+1)*terSca;
			 buffer[p++] = topo[i][j+1]*terSca/5;
			 buffer[p++] = i*terSca;

			 // quad 2
			 buffer[p++] = (j+1)*terSca;
			 buffer[p++] = topo[i+1][j+1]*terSca/5;
			 buffer[p++] = (i+1)*terSca;

			 // quad 3
			 buffer[p++] = j*terSca;
			 buffer[p++] = topo[i+1][j]*terSca/5;
			 buffer[p++] = (i+1)*terSca;
		 }
	}

	for (int i=0;i<512-1;i++){
		 for (int j=0;j<1024-1;j++){
			 // buffer
			 buffer[p++] = (float)j/1024;// x
			 buffer[p++] = (float)i/512;//y

			 buffer[p++] = (float)(j+1)/1024;// x
			 buffer[p++] = (float)i/512;//y

			 buffer[p++] = (float)(j+1)/1024;// x
			 buffer[p++] = (float)(i+1)/512;//y

			 buffer[p++] = (float)j/1024;// x
			 buffer[p++] = (float)(i+1)/512;//y
		 }
	}

	// bind VBO in order to use
	glBindBufferARB(GL_ARRAY_BUFFER_ARB,vboId);

	// upload data to VBO
	glBufferDataARB(GL_ARRAY_BUFFER_ARB,(1023*511*4*3+1023*511*4*2)*sizeof(GLfloat), buffer, GL_STATIC_DRAW_ARB);
	
	// it is safe to delete after copying data to VBO
	delete [] buffer;
}
void drawTerrain(){
	glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();

	// shader handle
   GLuint shaderProgramHandle;
   // light handle
   GLuint fvLightWorldCoordsHandle;
   // projection, viewing and model matrix handles
   GLuint fmProjHandle;
   GLuint fmViewHandle;
   GLuint fmModelHandle;
   // color handles 
   GLuint fvAmbientHandle;
   GLuint fvDiffuseHandle;
   GLuint fvSpecularHandle;
   GLuint fSpecularPowerHandle;
   GLuint fvBaseColorHandle;

   // sets the shader program for color or bump map
   shaderProgramHandle = shaderProgramHandles[ SHADER_BUMP_MAP ];
   
   glUseProgram( shaderProgramHandle );

   // handles to uniform variables for the shading program
   fvLightWorldCoordsHandle = glGetUniformLocation(shaderProgramHandle, "fvLightWorldCoords");
   fmProjHandle = glGetUniformLocation( shaderProgramHandle, "fmProj" );
   fmViewHandle = glGetUniformLocation( shaderProgramHandle, "fmView" );
   fmModelHandle = glGetUniformLocation( shaderProgramHandle, "fmModel" );
   fvAmbientHandle = glGetUniformLocation(shaderProgramHandle, "fvAmbient");
   fvDiffuseHandle = glGetUniformLocation(shaderProgramHandle, "fvDiffuse");
   fvSpecularHandle = glGetUniformLocation(shaderProgramHandle, "fvSpecular");
   fSpecularPowerHandle = glGetUniformLocation(shaderProgramHandle, "fSpecularPower");
   fvBaseColorHandle = glGetUniformLocation(shaderProgramHandle, "fvBaseColor");
    GLuint fvNormalHandle = glGetAttribLocation( shaderProgramHandle, "fvNormal" );
   GLuint fvTexCoordsHandle = glGetAttribLocation( shaderProgramHandle, "fvTexCoords" );;
   
   glUniform3fv( fvLightWorldCoordsHandle, 1, fvLightWorldCoords );
   glUniformMatrix4fv( fmProjHandle, 1, false, fmProj );
   glUniformMatrix4fv( fmViewHandle, 1, false, fmView );
   glUniformMatrix4fv( fmModelHandle, 1, false, fmModel );
   glUniform4fv(fvAmbientHandle, 1, fvAmbient);
   glUniform4fv(fvSpecularHandle, 1, fvSpecular);
   glUniform4fv(fvDiffuseHandle, 1, fvDiffuse);
   glUniform1fv(fSpecularPowerHandle, 1, fSpecularPower);
   glUniform4fv( fvBaseColorHandle, 1, fvBaseColor);
	
	glActiveTexture( GL_TEXTURE0 );
    glBindTexture( GL_TEXTURE_2D, textureHandles[ TEXTURE_MARS_COLOR_MAP ] );
    GLint colorMapHandle = glGetUniformLocation( shaderProgramHandle, "colorMap" );
    glUniform1i( colorMapHandle, 0 );
 
    glActiveTexture( GL_TEXTURE1 );
    glBindTexture( GL_TEXTURE_2D, textureHandles[ TEXTURE_MARS_NORMAL_MAP ] );
    GLint normalMapHandle = glGetUniformLocation( shaderProgramHandle, "normalMap" );
    glUniform1i( normalMapHandle, 1);

	glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboId);         // for vertex coordinates
	// enable vertex arrays
    glEnableClientState(GL_VERTEX_ARRAY);
	glEnableVertexAttribArray(fvTexCoordsHandle);
	glEnableVertexAttribArray(fvNormalHandle);

	glVertexAttribPointerARB(fvTexCoordsHandle, 2, GL_FLOAT, 0, 0, (void*)(1023*511*4*3*sizeof(GLfloat)));
	glVertexAttribPointerARB(fvNormalHandle, 2, GL_FLOAT, 0, 0, (void*)(1023*511*4*3*sizeof(GLfloat)));
	glVertexPointer(3, GL_FLOAT, 0, 0);               // last param is offset, not ptr
	
	// draw the quads 
	glDisable(GL_CULL_FACE);
	glDrawArrays(GL_QUADS, 0, 1023*511*4);
	glEnable(GL_CULL_FACE);

	// disable vertex arrays
	glDisableClientState(GL_VERTEX_ARRAY);  
	glDisableVertexAttribArray(fvTexCoordsHandle);
	glDisableVertexAttribArray(fvNormalHandle);

	glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0);
}
void drawSW(Textures texture,Textures textureT, float w, float s){
	glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();

	// shader handle
   GLuint shaderProgramHandle;
   // light handle
   GLuint fvLightWorldCoordsHandle;
   // projection, viewing and model matrix handles
   GLuint fmProjHandle;
   GLuint fmViewHandle;
   GLuint fmModelHandle;
   // color handles 
   GLuint fvAmbientHandle;
   GLuint fvDiffuseHandle;
   GLuint fvSpecularHandle;
   GLuint fSpecularPowerHandle;
   GLuint fvBaseColorHandle;

    glEnable( GL_BLEND );
      glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

   // sets the shader program for color or bump map
   shaderProgramHandle = shaderProgramHandles[ SHADER_CLOUD_MAP ];
   
   glUseProgram( shaderProgramHandle );

   // handles to uniform variables for the shading program
   fvLightWorldCoordsHandle = glGetUniformLocation(shaderProgramHandle, "fvLightWorldCoords");
   fmProjHandle = glGetUniformLocation( shaderProgramHandle, "fmProj" );
   fmViewHandle = glGetUniformLocation( shaderProgramHandle, "fmView" );
   fmModelHandle = glGetUniformLocation( shaderProgramHandle, "fmModel" );
   fvAmbientHandle = glGetUniformLocation(shaderProgramHandle, "fvAmbient");
   fvDiffuseHandle = glGetUniformLocation(shaderProgramHandle, "fvDiffuse");
   fvSpecularHandle = glGetUniformLocation(shaderProgramHandle, "fvSpecular");
   fSpecularPowerHandle = glGetUniformLocation(shaderProgramHandle, "fSpecularPower");
   fvBaseColorHandle = glGetUniformLocation(shaderProgramHandle, "fvBaseColor");
    GLuint fvNormalHandle = glGetAttribLocation( shaderProgramHandle, "fvNormal" );
   GLuint fvTexCoordsHandle = glGetAttribLocation( shaderProgramHandle, "fvTexCoords" );;
   
   glUniform3fv( fvLightWorldCoordsHandle, 1, fvLightWorldCoords );
   glUniformMatrix4fv( fmProjHandle, 1, false, fmProj );
   glUniformMatrix4fv( fmViewHandle, 1, false, fmView );
   glUniformMatrix4fv( fmModelHandle, 1, false, fmModel );
   glUniform4fv(fvAmbientHandle, 1, fvAmbient);
   glUniform4fv(fvSpecularHandle, 1, fvSpecular);
   glUniform4fv(fvDiffuseHandle, 1, fvDiffuse);
   glUniform1fv(fSpecularPowerHandle, 1, fSpecularPower);
   glUniform4fv( fvBaseColorHandle, 1, fvBaseColor);
	
	glActiveTexture( GL_TEXTURE2 );
      glBindTexture( GL_TEXTURE_2D, textureHandles[ texture ] );
      GLint cloudMapHandle = glGetUniformLocation( shaderProgramHandle, "cloudMap" );
      glUniform1i( cloudMapHandle, 2);
      // transparent map
      glActiveTexture( GL_TEXTURE3 );
      glBindTexture( GL_TEXTURE_2D, textureHandles[ textureT ] );
      GLint cloudTransMapHandle = glGetUniformLocation( shaderProgramHandle, "cloudTransMap" );
      glUniform1i( cloudTransMapHandle, 3);

	GLfloat swVer[] = {0,0,s,
						w,0,s,
						w,0,0,
						0,0,0};
	GLfloat swTex[] = {1,1,0,1,0,0,1,0};

	// enable vertex arrays
    glEnableClientState(GL_VERTEX_ARRAY);
	glEnableVertexAttribArray(fvTexCoordsHandle);

	glVertexAttribPointerARB(fvTexCoordsHandle, 2, GL_FLOAT, 0, 0,swTex);
	glVertexPointer(3, GL_FLOAT, 0, swVer);               // last param is offset, not ptr
	
	// draw the quads 
	glDisable(GL_CULL_FACE);
	glDrawArrays(GL_QUADS, 0, 4);
	glEnable(GL_CULL_FACE);

	// disable vertex arrays
	glDisableClientState(GL_VERTEX_ARRAY);  
	glDisableVertexAttribArray(fvTexCoordsHandle);

	glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0);
	glDisable( GL_BLEND );
}

void drawExplosion(Explosion ex){

	glPushAttrib(GL_LIGHTING_BIT | GL_CURRENT_BIT); // lighting and color mask
    glDisable(GL_LIGHTING);     // need to disable lighting for proper color
	glEnable( GL_BLEND );

	float color[4] = {0,0,0,0.5};
	float ran= (float)(rand()%500)/1000.0;
	float size = 0.5+ran;
	switch(ex.type){
		case 0: color[1] = 1; break;
		case 1: color[0] = 1; break;
		case 2: color[0]=0.5+ran; color[1]=ran*1.5; color[2]=ran/2; size = ran*3; break;
		case 3: color[0]=1; color[1]=0.7; color[2]=0.2; size = 2; break;
	}
	// transparent
	glPushMatrix();

	glTranslatef(ex.x,ex.y,ex.z+0.1);
	glColor4fv(color);    
	glutSolidSphere(float(ex.step)/40*size,10,10);
	glPopMatrix();
	glDisable( GL_BLEND );
	glEnable(GL_LIGHTING);
    glPopAttrib();
}
void explosion(float x, float y, float z, int ie){
	Explosion ex(ie,x,y,z);
	expVec.push_back(ex);
	//cout << expVec.size();
}
void drawString3D(const char *str, float pos[3], float color[4], void *font)
{
    glPushAttrib(GL_LIGHTING_BIT | GL_CURRENT_BIT); // lighting and color mask
    glDisable(GL_LIGHTING);     // need to disable lighting for proper text color

    glColor4fv(color);          // set text color
    glRasterPos3fv(pos);        // place text position

    // loop all characters in the string
    while(*str)
    {
        glutBitmapCharacter(font, *str);
        ++str;
    }

    glEnable(GL_LIGHTING);
    glPopAttrib();
}
// This function was provided by the CS175 HW3/HW4 solutions.
void enableLights(){
	glEnable(GL_LIGHTING);

	float ambient[4] = {0.5,0.5,0.5,1};
	float diffuse[4] = {0.5,0.5,0.5,1};
	float specular[4] = {0.5,0.5,0.5,1};

	float nopos[4]={0.f,-10.f,20.f,0.f};
	
	// ambient light source
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT,ambient);

	// white directional light source
	//glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	//glLoadIdentity();
	//cam.apply();
	glEnable(GL_LIGHT1);
	//glLightfv(GL_LIGHT1,GL_POSITION,fvLightWorldCoords);
	glLightfv(GL_LIGHT1,GL_POSITION,nopos);
	glLightfv(GL_LIGHT1,GL_AMBIENT,ambient);
	glLightfv(GL_LIGHT1,GL_DIFFUSE,diffuse);
	glLightfv(GL_LIGHT1,GL_SPECULAR,specular);
	glPopMatrix();
}
// This function was provided by the CS175 HW3/HW4 solutions.
void disableLights(){
	glDisable(GL_LIGHTING);
}


// This function was provided by the CS175 HW3/HW4 solutions.
void drawSphere(GLuint shaderProgramHandle, bool texCoordsFlag, bool tangentBinormalFlag, float radius, int numSlices, int numStacks)
{
   GLuint fvNormalHandle = glGetAttribLocation( shaderProgramHandle, "fvNormal" );
   GLuint fvTexCoordsHandle;
   GLuint fvTangentHandle;
   GLuint fvBinormalHandle;

   if (texCoordsFlag)
   {
      fvTexCoordsHandle  = glGetAttribLocation( shaderProgramHandle, "fvTexCoords" );
   }

   if (tangentBinormalFlag)
   {
      fvTangentHandle = glGetAttribLocation( shaderProgramHandle, "fvTangent" );
      fvBinormalHandle = glGetAttribLocation( shaderProgramHandle, "fvBinormal" );
   }

   float dphi = 3.141592653589f / (float)numStacks;
   float dtheta = (2.0f * 3.141592653589f) / (float)numSlices;

   float ds = 1.0f / (float)numSlices;
   float dt = 1.0f / (float)numStacks;

   float t = 1.0;

   glBegin( GL_TRIANGLES );

   for( int i = 0; i < numStacks; i++ )
   {
      float phi = (float)i * dphi;
      float cosPhi = cos(phi);
      float sinPhi = sin(phi);
      float cosPhiPlusdphi = cos(phi + dphi);
      float sinPhiPlusdphi = sin(phi + dphi);

      float s = 0.0;

      for ( int j = 0; j < numSlices; j++ )
      {
         float theta = (float)j * dtheta;
         float cosTheta = (float)cos(theta);
         float sinTheta = (float)sin(theta);

         float thetaPlusdtheta = ((j+1) == numSlices) ? 0.0f : (float)(j+1) * dtheta;
         float cosThetaPlusdtheta = (float)cos( thetaPlusdtheta );
         float sinThetaPlusdtheta = (float)sin( thetaPlusdtheta );

         // compute four tangents
         float tx[4], ty[4], tz[4];

         // (theta, phi)
         tx[0] = -sinTheta;
         ty[0] = cosTheta;
         tz[0] = 0.0f;

         // (theta, phi + dphi)
         tx[1] = -sinTheta;
         ty[1] = cosTheta;
         tz[1] = 0.0f;

         // (theta + dtheta, phi + dphi)
         tx[2] = -sinThetaPlusdtheta;
         ty[2] = cosThetaPlusdtheta;
         tz[2] = 0.0f;

         // (theta + dtheta, phi)
         tx[3] = -sinThetaPlusdtheta;
         ty[3] = cosThetaPlusdtheta;
         tz[3] = 0.0f;

         // compute four binormals
         float bx[4], by[4], bz[4];

         // (theta, phi)
         bx[0] = -cosTheta * cosPhi;
         by[0] = -sinTheta * cosPhi;
         bz[0] = sinPhi;

         // (theta, phi + dphi)
         bx[1] = -cosTheta * cosPhiPlusdphi;
         by[1] = -sinTheta * cosPhiPlusdphi;
         bz[1] = sinPhiPlusdphi;

         // (theta + dtheta, phi + dphi)
         bx[2] = -cosThetaPlusdtheta * cosPhiPlusdphi;
         by[2] = -sinThetaPlusdtheta * cosPhiPlusdphi;
         bz[2] = sinPhiPlusdphi;

         // (theta + dtheta, phi)
         bx[3] = -cosThetaPlusdtheta * cosPhi;
         by[3] = -sinThetaPlusdtheta * cosPhi;
         bz[3] = sinPhi;

         // define the four corners of the patch
         // compute four normals
         float nx[4], ny[4], nz[4];

         // (theta, phi)
         nx[0] = cosTheta * sinPhi;
         ny[0] = sinTheta * sinPhi;
         nz[0] = cosPhi;

         // (theta, phi + dphi)
         nx[1] = cosTheta * sinPhiPlusdphi;
         ny[1] = sinTheta * sinPhiPlusdphi;
         nz[1] = cosPhiPlusdphi;

         // (theta + dtheta, phi + dphi)
         nx[2] = cosThetaPlusdtheta * sinPhiPlusdphi;
         ny[2] = sinThetaPlusdtheta * sinPhiPlusdphi;
         nz[2] = cosPhiPlusdphi;

         // (theta + dtheta, phi)
         nx[3] = cosThetaPlusdtheta * sinPhi;
         ny[3] = sinThetaPlusdtheta * sinPhi;
         nz[3] = cosPhi;

         // compute four vertices
         float vx[4], vy[4], vz[4];
         for( int k = 0; k < 4; k++ )
         {
            vx[k] = radius * nx[k];
            vy[k] = radius * ny[k];
            vz[k] = radius * nz[k];
         }

         // first triangle
         if (tangentBinormalFlag)
         {
            glVertexAttrib3f( fvTangentHandle, tx[0], ty[0], tz[0]);
            glVertexAttrib3f( fvBinormalHandle, bx[0], by[0], bz[0]);
         }
         glVertexAttrib3f( fvNormalHandle, nx[0], ny[0], nz[0]);
         if (texCoordsFlag)
         {
            glVertexAttrib2f( fvTexCoordsHandle, s, t);
         }
         glVertex3f( vx[0], vy[0], vz[0] );

         if (tangentBinormalFlag)
         {
            glVertexAttrib3f( fvTangentHandle, tx[1], ty[1], tz[1]);
            glVertexAttrib3f( fvBinormalHandle, bx[1], by[1], bz[1]);
         }
         glVertexAttrib3f( fvNormalHandle, nx[1], ny[1], nz[1]);
         if (texCoordsFlag)
         {
            glVertexAttrib2f( fvTexCoordsHandle, s, t - dt);
         }
         glVertex3f( vx[1], vy[1], vz[1] );
         
         if (tangentBinormalFlag)
         {
            glVertexAttrib3f( fvTangentHandle, tx[3], ty[3], tz[3]);
            glVertexAttrib3f( fvBinormalHandle, bx[3], by[3], bz[3]);
         }
         glVertexAttrib3f( fvNormalHandle, nx[3], ny[3], nz[3]);
         if (texCoordsFlag)
         {
            glVertexAttrib2f( fvTexCoordsHandle, s + ds, t );
         }
         glVertex3f( vx[3], vy[3], vz[3] );
         
         // second triangle
         if (tangentBinormalFlag)
         {
            glVertexAttrib3f( fvTangentHandle, tx[1], ty[1], tz[1]);
            glVertexAttrib3f( fvBinormalHandle, bx[1], by[1], bz[1]);
         }
         glVertexAttrib3f( fvNormalHandle, nx[1], ny[1], nz[1]);
         if (texCoordsFlag)
         {
            glVertexAttrib2f( fvTexCoordsHandle, s, t - dt);
         }
         glVertex3f( vx[1], vy[1], vz[1] );
         
         if (tangentBinormalFlag)
         {
            glVertexAttrib3f( fvTangentHandle, tx[2], ty[2], tz[2]);
            glVertexAttrib3f( fvBinormalHandle, bx[2], by[2], bz[2]);
         }
         glVertexAttrib3f( fvNormalHandle, nx[2], ny[2], nz[2]);
         if (texCoordsFlag)
         {
            glVertexAttrib2f( fvTexCoordsHandle, s + ds, t - dt );
         }
         glVertex3f( vx[2], vy[2], vz[2] );

         if (tangentBinormalFlag)
         {
            glVertexAttrib3f( fvTangentHandle, tx[3], ty[3], tz[3]);
            glVertexAttrib3f( fvBinormalHandle, bx[3], by[3], bz[3]);
         }
         glVertexAttrib3f( fvNormalHandle, nx[3], ny[3], nz[3]);
         if (texCoordsFlag)
         {
            glVertexAttrib2f( fvTexCoordsHandle, s + ds, t );
         }
         glVertex3f( vx[3], vy[3], vz[3] );

         s += ds;
      }

      t -= dt;
   }

   glEnd();
}
// This function was provided by the CS175 HW3/HW4 solutions.
void drawCube( float radius )
{
   glBegin( GL_TRIANGLES );
   
   /////////////////////////////////////////////
   // Top of cube
   glNormal3f(0.0f, radius, 0.0f);
   glVertex3f(radius, radius, radius);

   glNormal3f(0.0f, radius, 0.0f);
   glVertex3f(radius, radius, -radius);

   glNormal3f(0.0f, radius, 0.0f);
   glVertex3f(-radius, radius, -radius);

   glNormal3f(0.0f, radius, 0.0f);
   glVertex3f(radius, radius, radius);

   glNormal3f(0.0f, radius, 0.0f);
   glVertex3f(-radius, radius, -radius);

   glNormal3f(0.0f, radius, 0.0f);
   glVertex3f(-radius, radius, radius);

   ////////////////////////////////////////////
   // Bottom of cube
   glNormal3f(0.0f, -radius, 0.0f);
   glVertex3f(-radius, -radius, -radius);

   glNormal3f(0.0f, -radius, 0.0f);
   glVertex3f(radius, -radius, -radius);

   glNormal3f(0.0f, -radius, 0.0f);
   glVertex3f(radius, -radius, radius);

   glNormal3f(0.0f, -radius, 0.0f);
   glVertex3f(-radius, -radius, radius);

   glNormal3f(0.0f, -radius, 0.0f);
   glVertex3f(-radius, -radius, -radius);

   glNormal3f(0.0f, -radius, 0.0f);
   glVertex3f(radius, -radius, radius);

   ///////////////////////////////////////////
   // Left side of cube
   glNormal3f(-radius, 0.0f, 0.0f);
   glVertex3f(-radius, radius, radius);

   glNormal3f(-radius, 0.0f, 0.0f);
   glVertex3f(-radius, radius, -radius);

   glNormal3f(-radius, 0.0f, 0.0f);
   glVertex3f(-radius, -radius, -radius);

   glNormal3f(-radius, 0.0f, 0.0f);
   glVertex3f(-radius, radius, radius);

   glNormal3f(-radius, 0.0f, 0.0f);
   glVertex3f(-radius, -radius, -radius);

   glNormal3f(-radius, 0.0f, 0.0f);
   glVertex3f(-radius, -radius, radius);

   // Right side of cube
   glNormal3f(radius, 0.0f, 0.0f);
   glVertex3f(radius, -radius, -radius);

   glNormal3f(radius, 0.0f, 0.0f);
   glVertex3f(radius, radius, -radius);

   glNormal3f(radius, 0.0f, 0.0f);
   glVertex3f(radius, radius, radius);

   glNormal3f(radius, 0.0f, 0.0f);
   glVertex3f(radius, radius, radius);

   glNormal3f(radius, 0.0f, 0.0f);
   glVertex3f(radius, -radius, radius);

   glNormal3f(radius, 0.0f, 0.0f);
   glVertex3f(radius, -radius, -radius);

   // Front and Back
   // Front
   glNormal3f(0.0f, 0.0f, radius);
   glVertex3f(radius, -radius, radius);

   glNormal3f(0.0f, 0.0f, radius);
   glVertex3f(radius, radius, radius);

   glNormal3f(0.0f, 0.0f, radius);
   glVertex3f(-radius, radius, radius);

   glNormal3f(0.0f, 0.0f, radius);
   glVertex3f(-radius, radius, radius);

   glNormal3f(0.0f, 0.0f, radius);
   glVertex3f(-radius, -radius, radius);

   glNormal3f(0.0f, 0.0f, radius);
   glVertex3f(radius, -radius, radius);

   // Back
   glNormal3f(0.0f, 0.0f, -radius);
   glVertex3f(radius, -radius, -radius);

   glNormal3f(0.0f, 0.0f, -radius);
   glVertex3f(-radius, -radius, -radius);

   glNormal3f(0.0f, 0.0f, -radius);
   glVertex3f(-radius, radius, -radius);

   glNormal3f(0.0f, 0.0f, -radius);
   glVertex3f(-radius, radius, -radius);

   glNormal3f(0.0f, 0.0f, -radius);
   glVertex3f(radius, radius, -radius);

   glNormal3f(0.0f, 0.0f, -radius);
   glVertex3f(radius, -radius, -radius);
   
   glEnd();
}
// This function was provided by the CS175 HW3/HW4 solutions.
void drawPlanet(   DrawMode drawMode = DRAW_PHONG, float planetRadius = 1.0f, 
                   Textures colorMapTexture = TEXTURE_EARTH_COLOR_MAP, Textures normalMapTexture = TEXTURE_EARTH_NORMAL_MAP,
                   bool cloudMapFlag = false, float cloudRadius = 1.05f, 
                   Textures cloudMapTexture = TEXTURE_EARTH_CLOUD_MAP, Textures cloudTransMapTexture = TEXTURE_EARTH_CLOUD_TRANS_MAP) 
{
   // shader handle
   GLuint shaderProgramHandle;
   // light handle
   GLuint fvLightWorldCoordsHandle;
   // projection, viewing and model matrix handles
   GLuint fmProjHandle;
   GLuint fmViewHandle;
   GLuint fmModelHandle;
   // color handles 
   GLuint fvAmbientHandle;
   GLuint fvDiffuseHandle;
   GLuint fvSpecularHandle;
   GLuint fSpecularPowerHandle;
   GLuint fvBaseColorHandle;

   // sets the shader program for color or bump map
   switch( drawMode )
   {
   case DRAW_PHONG:
      {
         shaderProgramHandle = shaderProgramHandles[ SHADER_PHONG ];
         break;
      }
   case DRAW_COLOR_MAP:
      {
         shaderProgramHandle = shaderProgramHandles[ SHADER_COLOR_MAP ];
         break;
      }
   case DRAW_BUMP_MAP:
      {
         shaderProgramHandle = shaderProgramHandles[ SHADER_BUMP_MAP ];
         break;
      }
   }
   
   glUseProgram( shaderProgramHandle );

   // handles to uniform variables for the shading program
   fvLightWorldCoordsHandle = glGetUniformLocation(shaderProgramHandle, "fvLightWorldCoords");
   fmProjHandle = glGetUniformLocation( shaderProgramHandle, "fmProj" );
   fmViewHandle = glGetUniformLocation( shaderProgramHandle, "fmView" );
   fmModelHandle = glGetUniformLocation( shaderProgramHandle, "fmModel" );
   fvAmbientHandle = glGetUniformLocation(shaderProgramHandle, "fvAmbient");
   fvDiffuseHandle = glGetUniformLocation(shaderProgramHandle, "fvDiffuse");
   fvSpecularHandle = glGetUniformLocation(shaderProgramHandle, "fvSpecular");
   fSpecularPowerHandle = glGetUniformLocation(shaderProgramHandle, "fSpecularPower");
   fvBaseColorHandle = glGetUniformLocation(shaderProgramHandle, "fvBaseColor");

   glUniform3fv( fvLightWorldCoordsHandle, 1, fvLightWorldCoords );
   glUniformMatrix4fv( fmProjHandle, 1, false, fmProj );
   glUniformMatrix4fv( fmViewHandle, 1, false, fmView );
   glUniformMatrix4fv( fmModelHandle, 1, false, fmModel );
   glUniform4fv(fvAmbientHandle, 1, fvAmbient);
   glUniform4fv(fvSpecularHandle, 1, fvSpecular);
   glUniform4fv(fvDiffuseHandle, 1, fvDiffuse);
   glUniform1fv(fSpecularPowerHandle, 1, fSpecularPower);
   glUniform4fv( fvBaseColorHandle, 1, fvBaseColor);

   if ( ( drawMode == DRAW_COLOR_MAP ) || ( drawMode == DRAW_BUMP_MAP ) )
   {
      // color map (only used in colormap shader)
      glActiveTexture( GL_TEXTURE0 );
      glBindTexture( GL_TEXTURE_2D, textureHandles[ colorMapTexture ] );
      GLint colorMapHandle = glGetUniformLocation( shaderProgramHandle, "colorMap" );
      glUniform1i( colorMapHandle, 0 );
   }
   
   if ( drawMode == DRAW_BUMP_MAP ) // bumpmap
   {
      // normal map (only used in bumpmap shader
      glActiveTexture( GL_TEXTURE1 );
      glBindTexture( GL_TEXTURE_2D, textureHandles[ normalMapTexture ] );
      GLint normalMapHandle = glGetUniformLocation( shaderProgramHandle, "normalMap" );
      glUniform1i( normalMapHandle, 1);
   }

   // draw planet
   switch ( drawMode )
   {
      case DRAW_PHONG:
         {
            drawSphere( shaderProgramHandle, false, false, planetRadius, 100.0, 100.0 );
            break;
         }
      case DRAW_COLOR_MAP:
         {
            drawSphere( shaderProgramHandle, true, false, planetRadius, 100.0, 100.0 );
            break;
         }
      case DRAW_BUMP_MAP:
         {
            drawSphere( shaderProgramHandle, true, true, planetRadius, 100.0, 100.0 );
            break;
         }
   }

   // draw cloud map
   if (cloudMapFlag)
   {
      // sets the shader program for color or bump map
      glEnable( GL_BLEND );
      glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

      shaderProgramHandle = shaderProgramHandles[ SHADER_CLOUD_MAP ]; 
      glUseProgram( shaderProgramHandle );

      // Handles to uniform variables for the shading program
      fvLightWorldCoordsHandle = glGetUniformLocation(shaderProgramHandle, "fvLightWorldCoords");
      fmProjHandle = glGetUniformLocation( shaderProgramHandle, "fmProj" );
      fmViewHandle = glGetUniformLocation( shaderProgramHandle, "fmView" );
      fmModelHandle = glGetUniformLocation( shaderProgramHandle, "fmModel" );
      fvAmbientHandle = glGetUniformLocation(shaderProgramHandle, "fvAmbient");
      fvDiffuseHandle = glGetUniformLocation(shaderProgramHandle, "fvDiffuse");
      fvSpecularHandle = glGetUniformLocation(shaderProgramHandle, "fvSpecular");
      fSpecularPowerHandle = glGetUniformLocation(shaderProgramHandle, "fSpecularPower");
      fvBaseColorHandle = glGetUniformLocation(shaderProgramHandle, "fvBaseColor");

      glUniform3fv( fvLightWorldCoordsHandle, 1, fvLightWorldCoords );
      glUniformMatrix4fv( fmProjHandle, 1, false, fmProj );
      glUniformMatrix4fv( fmViewHandle, 1, false, fmView );
      glUniformMatrix4fv( fmModelHandle, 1, false, fmModel );
      glUniform4fv(fvAmbientHandle, 1, fvAmbient);
      glUniform4fv(fvSpecularHandle, 1, fvSpecular);
      glUniform4fv(fvDiffuseHandle, 1, fvDiffuse);
      glUniform1fv(fSpecularPowerHandle, 1, fSpecularPower);
      glUniform4fv( fvBaseColorHandle, 1, fvBaseColor);

      // cloud map
      glActiveTexture( GL_TEXTURE2 );
      glBindTexture( GL_TEXTURE_2D, textureHandles[ cloudMapTexture ] );
      GLint cloudMapHandle = glGetUniformLocation( shaderProgramHandle, "cloudMap" );
      glUniform1i( cloudMapHandle, 2);
      // cloud transparent map
      glActiveTexture( GL_TEXTURE3 );
      glBindTexture( GL_TEXTURE_2D, textureHandles[ cloudTransMapTexture ] );
      GLint cloudTransMapHandle = glGetUniformLocation( shaderProgramHandle, "cloudTransMap" );
      glUniform1i( cloudTransMapHandle, 3);

      drawSphere( shaderProgramHandle, true, false, cloudRadius, 100.0, 100.0);

      glDisable( GL_BLEND );
   }
}

void sceneTrans1(){

	glPushMatrix();
	//draw mars
	glTranslatef( -2.5f, -1.0f, -0.5f );
	glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
		drawPlanet( activeDrawMode, 0.6f, TEXTURE_MARS_COLOR_MAP, TEXTURE_MARS_NORMAL_MAP );
   glPopMatrix();

   glPushMatrix();
		glTranslatef( -4.0f, -0.8f, 0.5f );
		// draw earth
		glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
		drawPlanet( activeDrawMode, 0.4f, TEXTURE_EARTH_COLOR_MAP, TEXTURE_EARTH_NORMAL_MAP, 
               drawClouds, 0.405f, TEXTURE_EARTH_CLOUD_MAP, TEXTURE_EARTH_CLOUD_TRANS_MAP );

	glPopMatrix();

	glPushMatrix();

      glTranslatef( -6.0f, -0.0f, 1.0f );
	  glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
      drawPlanet( DRAW_COLOR_MAP, 1.0f, TEXTURE_SUN_COLOR_MAP );

   glPopMatrix();

   glPushMatrix();
   
      glTranslatef( -4.0f, -0.0f, 0.5f );
      
      // draw moon
      glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
      drawPlanet( activeDrawMode, 0.2f, TEXTURE_MOON_COLOR_MAP, TEXTURE_MOON_NORMAL_MAP );

   glPopMatrix();

    glPushMatrix();
		glRotatef(90,1,0,0);
		glTranslatef( -terSca*512.0f,-terSca*32.0f,-terSca*256.0f );
		 glTranslatef( 40.0f,0,0 );
		glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
			drawTerrain();
   glPopMatrix();

}
void drawScene()
{
	// get model matrix M
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();

   switch(sequence){
   case 1:

	   // SW Logo
    glPushMatrix();
		glTranslatef( -0.5f, 1.0f, -0.25f );
		glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
		drawSW(TEXTURE_SWLOGO,TEXTURE_SWLOGOT,1,0.5);
   glPopMatrix();
   break;

   case 2:
	    // SW Crawl
   glPushMatrix();
   glRotatef(75,1,0,0);
		glTranslatef( -0.3f, 0.12f, -2.6f );
		glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
		drawSW(TEXTURE_SWCRAWL,TEXTURE_SWCRAWLT,0.6,1.8);
   glPopMatrix();
   break;

   case 3:
   case 6:
	   glPushMatrix();
	//draw mars at origin
	glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
		//drawPlanet( activeDrawMode, 0.4f, TEXTURE_MARS_COLOR_MAP, TEXTURE_MARS_NORMAL_MAP );
   glPopMatrix();

   glPushMatrix();
		glTranslatef( -2.0f, 0.0f, 2.5f );
		// draw earth
		glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
		drawPlanet( activeDrawMode, 0.2f, TEXTURE_EARTH_COLOR_MAP, TEXTURE_EARTH_NORMAL_MAP, 
               drawClouds, 0.205f, TEXTURE_EARTH_CLOUD_MAP, TEXTURE_EARTH_CLOUD_TRANS_MAP );

	glPopMatrix();

	glPushMatrix();

      glTranslatef( -5.5f, 1.0f, 4.0f );
	  glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
      drawPlanet( DRAW_COLOR_MAP, 0.8f, TEXTURE_SUN_COLOR_MAP );

   glPopMatrix();

   glPushMatrix();
   
      glTranslatef( -2.0f, 0.5f, 2.5f );
      
      // draw moon
      glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
      drawPlanet( activeDrawMode, 0.1f, TEXTURE_MOON_COLOR_MAP, TEXTURE_MOON_NORMAL_MAP );

   glPopMatrix();

   glPushMatrix();
  glRotatef(90,1,0,0);
		glTranslatef( -terSca*512.0f,-terSca*32.0f,-terSca*256.0f );
		 
		glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
			drawTerrain();
   glPopMatrix();
   break;
   case 4:
	    glPushMatrix();
  glRotatef(90,1,0,0);
		glTranslatef( -terSca*512.0f,-terSca*32.0f,-terSca*256.0f );
		
		if (battleN==6){
			glTranslatef(0,landOffset,0);
			landOffset -= 5.0f/100;
		}
		glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
			drawTerrain();
   glPopMatrix();

   if (gameOver){
	   PlaySound(NULL, 0, 0);
	   moveable=false; mousefire=false;
	   cam.getLocation(loc);
	   glPushMatrix();
	    glLoadIdentity();
		glTranslatef( loc[0]-0.5,loc[1]-0.38,loc[2]-0.48 );
		glRotatef(28,1,0,0);
		glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
		drawSW(TEXTURE_SWGG,TEXTURE_SWGGT,1,0.5);
	   glPopMatrix();
   }

   break;
   case 5:
	   sceneTrans1();
	   break;
   case 20:
	glPushMatrix();
		glTranslatef( -0.5f, 0.4f, -0.25f );
		glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
		drawSW(TEXTURE_SWBEAT,TEXTURE_SWBEATT,1,0.5);
   glPopMatrix();
   break;
   }
}
void renderLaser(){
	 glEnable( GL_BLEND );

	float col[] = {0,1,0,0.8};

	for (int i=laserVec.size()-1;i>=0;i--) {
		Laser laser = laserVec[i];
		
		
		glPushMatrix();
		// rotate the laser
		
		glRotatef(90,1,0,0);
		// move laser
		glTranslatef(laser.loc[0],laser.loc[2],-laser.loc[1]);
		// draw laser
		glRotatef(laser.angle1,0,1,0);
		glColor4fv(col);  
		glutSolidCone(0.02,0.4,10,10);
		glPopMatrix();

		 
	}

	float enemyCol[] ={1,0,0,0.8};

	for (int i=enemyLaserVec.size()-1;i>=0;i--) {
		Laser laser = enemyLaserVec[i];

		glPushMatrix();
		// rotate the laser
		
		glRotatef(270,1,0,0);
		// move laser
		glTranslatef(-laser.loc[0],-laser.loc[2],laser.loc[1]);
		// draw laser
		glRotatef(laser.angle2,0,1,0);
		glColor4fv(enemyCol);  
		glutSolidCone(0.02,0.4,10,10);
		glPopMatrix();
	}

	glDisable(GL_BLEND);
}

void renderExplosion(){

	for(int i=expVec.size()-1;i>=0;i--){
		
		if (expVec[i].step==16){
			expVec.erase(expVec.begin()+i);
		}
		else
		{
			// render
			drawExplosion(expVec[i]);

			expVec[i].step++;
		}
	}

}
void renderUnit(Unit unit){
	enableLights();
	glEnable( GL_BLEND );
	glPushMatrix();
		
		glRotatef(unit.rotate[0],1,0,0);
		glRotatef(unit.rotate[1],0,1,0);
		glTranslatef(unit.loc[0],unit.loc[1],unit.loc[2]);
		if (battleN!=6)
			glRotatef(((shipX-unit.unitX)/400.0f)*30,0,1,0);
		glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
		glScalef(unit.scale,unit.scale,unit.scale);

		(*(Model3D*)unit.model).render();
	
	glPopMatrix();
	glDisable(GL_BLEND);
	disableLights();
}
void renderBound(Unit unit){
	glPushMatrix();
		glTranslatef(unit.center[0],unit.center[1],unit.center[2]);
		glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
		
		glutWireSphere(unit.radius,10,10);
	
	glPopMatrix();
}

void explodeOff(int i){
	explodeSound=false;
}
bool loopUnits(){

	bool unitsAlive = false;
	int n = unitVec.size();

	for (int i=0;i<n;i++){
		
		if (unitVec[i].renderState >100){
			unitVec[i].animate();
		} else if (unitVec[i].renderState>0 && unitVec[i].renderState < 100){
			if (battleN==6)
			{
				unitVec[i].renderState=0; 
			}
			else
			{
				if (!unitVec[i].exploded)
				{
				// one big explosion at middle
				explosion(unitVec[i].center[0],unitVec[i].center[1],unitVec[i].center[2],3);
				// play one of four explosion sounds
				int dr = rand() % 4;
				explodeSound=true;
				PlaySound(NULL, 0, 0);
				glutTimerFunc( 2000,explodeOff, 0);
				switch(dr){
					case 0: 
						PlaySound(L"Sounds/explosion-01.wav", NULL, SND_FILENAME | SND_ASYNC |SND_NOSTOP); break;
					case 1: 
						PlaySound(L"Sounds/explosion-02.wav", NULL, SND_FILENAME | SND_ASYNC | SND_NOSTOP); break;
					case 2: 
						PlaySound(L"Sounds/explosion-03.wav", NULL, SND_FILENAME | SND_ASYNC | SND_NOSTOP); break;
					case 3: 
						PlaySound(L"Sounds/explosion-04.wav", NULL, SND_FILENAME | SND_ASYNC | SND_NOSTOP); break;
				}
				unitVec[i].exploded = true;
				}

				if (unitVec[i].renderState%10==0 && unitVec[i].renderState>30){
					// random explosions
					float dr1 = rand()%1000/1000.0-0.5;
					float dr2 = rand()%1000/1000.0-0.5;
					float dr3 = rand()%1000/1000.0-0.5;
					explosion(unitVec[i].center[0]+dr1,unitVec[i].center[1]+dr2,unitVec[i].center[2]-0.5+dr3,2);
				}
				unitVec[i].animate();
			}
		} else if (unitVec[i].renderState == 100){
			if (drawBounds && devMode)
				renderBound(unitVec[i]);

			// draw hp
			float pos[3]= {unitVec[i].center[0],unitVec[i].center[1]+unitVec[i].radius,unitVec[i].center[2]+unitVec[i].radius};
			float col[4] = {1,0,0,1};
			char str[20]; 
			char hp[5];
			strcpy (str,"HP: ");
			itoa (unitVec[i].hp,hp,10);
			strcat (str,hp);
			strcat (str,"/");
			itoa (unitVec[i].maxhp,hp,10);
			strcat (str,hp);
			drawString3D(str, pos,col,GLUT_BITMAP_HELVETICA_12);

			// enemy attacks with some random chance
			int randomN = rand() % 100*33 + 1;
			if (randomN<unitVec[i].fireChance){
				unitVec[i].fireLag--;
				if (!unitVec[i].fireLag){
					unitVec[i].fireLag=5;
					Laser laser(-unitVec[i].center[0],unitVec[i].center[1],unitVec[i].center[2],(float)(shipX-400)/200.0f,-0.2,0,true);
					enemyLaserVec.push_back(laser);
				}
			}
		} 
		
		if (unitVec[i].renderState!=0){	
			unitsAlive=true;
			renderUnit(unitVec[i]);
		}
	}

	if (unitsAlive){
		if (battleN==6)
			renderUnit(unitVec[0]);

		return true;
	}else{
		return false;
	}
}

void battle1(){
	// initialize units
	if (initUnits[1]==false){
		Unit unit(&trifighter,0.003,0,0,-7,90,180,0,0,5,0,400,200*diffMulti,0.3,120*diffMulti);
		unit.setCenter(0,-7,0);
		unitVec.push_back(unit);
		Unit unit2(&trifighter,0.003,-4,0,-6,90,180,0,0,5,0,000,200*diffMulti,0.3,120*diffMulti);
		unit2.setCenter(4,-6,0);
		unitVec.push_back(unit2);
		Unit unit3(&trifighter,0.003,4,0,-6,90,180,0,0,5,0,800,200*diffMulti,0.3,120*diffMulti);
		unit3.setCenter(-4,-6,0);
		unitVec.push_back(unit3);
		initUnits[1]=true;
	}
}

void battle2(){
	// initialize units
	if (initUnits[2]==false){
		Unit unit(&yt1300,0.015,1.5,0,5,90,0,0,0,5,5,400,500*diffMulti,0.8,150*diffMulti);
		unit.setCenter(0,-5,0);
		unitVec.push_back(unit);
		Unit unit2(&jedi,0.007,3,0,-4,90,180,0,3,2,0,600,100*diffMulti,0.3,60*diffMulti);
		unit2.setCenter(-3,-4,0.25);
		unitVec.push_back(unit2);
		Unit unit3(&jedi,0.007,4,0,-3.5,90,180,0,4,2,0,800,100*diffMulti,0.3,60*diffMulti);
		unit3.setCenter(-4,-3.5,0.25);
		unitVec.push_back(unit3);
		Unit unit4(&jedi,0.007,-3,0,-4,90,180,0,-3,2,0,200,100*diffMulti,0.3,60*diffMulti);
		unit4.setCenter(3,-4,0.25);
		unitVec.push_back(unit4);
		Unit unit5(&jedi,0.007,-4,0,-3.5,90,180,0,-4,2,0,0,100*diffMulti,0.3,60*diffMulti);
		unit5.setCenter(4,-3.5,0.25);
		unitVec.push_back(unit5);
		initUnits[2]=true;
	}
}

void battle3(){

	if (initUnits[3]==false){
		Unit unit(&enemy,0.005,0,0,-6,90,180,0,0,0,-10,400,800*diffMulti,0.4,180*diffMulti);
		unit.setCenter(0,-6,0);
		unitVec.push_back(unit);
		Unit unit2(&enemy,0.005,-3,0,-6,90,180,0,0,0,-10,200,800*diffMulti,0.4,180*diffMulti);
		unit2.setCenter(3,-6,0);
		unitVec.push_back(unit2);
		Unit unit3(&enemy,0.005,3,0,-6,90,180,0,0,0,-10,600,800*diffMulti,0.4,180*diffMulti);
		unit3.setCenter(-3,-6,0);
		unitVec.push_back(unit3);
		initUnits[3]=true;
	}
}

void battle4(){

	if (initUnits[4]==false){
		for (int i=-4;i<=4;i++){
			Unit unit(&jedi,0.007,-i,-0.2,-4,90,180,0,-i*2,0,-8,400-150*i,150*diffMulti,0.3,100*diffMulti);
			unit.setCenter(i,-4,0.00);
			unitVec.push_back(unit);
			Unit unit2(&jedi,0.007,-i,0.5,-4.2,90,180,0,-i*2,0,-8,400-150*i,150*diffMulti,0.3,100*diffMulti);
			unit2.setCenter(i,-4.2,0.70);
			unitVec.push_back(unit2);
		}
		initUnits[4]=true;
	}
}

void battle5(){

	if (initUnits[5]==false){
		for (int i=-4;i<=4;i+=4){
			Unit unit(&trifighter,0.0025,-i*1.3,-0.2,-6,90,180,0,-i*2,5,-2,400-150*i,800*diffMulti,0.3,120*diffMulti);
			unit.setCenter(i*1.3,-6,-0.1);
			unitVec.push_back(unit);
			Unit unit2(&trifighter,0.0025,-i,0.5,-6.5,90,180,0,-i*2,5,-2,400-150*i,800*diffMulti,0.3,120*diffMulti);
			unit2.setCenter(i,-6.5,0.60);
			unitVec.push_back(unit2);
		}

		for (int i=-2;i<=2;i+=4){
			Unit unit(&enemy,0.005,-i,0.5,-6,90,180,0,0,0,-10,400-150*i,600*diffMulti,0.4,180*diffMulti);
			unit.setCenter(i,-6,0.5);
			unitVec.push_back(unit);
			Unit unit2(&enemy,0.005,-i*1.3,0,-5.2,90,180,0,0,0,-10,400-150*i,600*diffMulti,0.4,180*diffMulti);
			unit2.setCenter(i*1.3,-5.2,0);
			unitVec.push_back(unit2);
		}

		initUnits[5]=true;
	}

}

void battleDS(){

	if (initUnits[6]==false){
		PlaySound(L"Sounds/darthvader.wav", NULL, SND_FILENAME | SND_ASYNC);

		Unit unit(&deathStar,0.03,4.8,-2,-7,90,180,0,0,10,0,400,(diffMulti==0.5) ? 9999:99999,0.3,500*diffMulti);
		unit.setCenter(0,-6,0.5);
		unitVec.push_back(unit);
		Unit unit2(&nothing,0.03,4.8,-2,-7,90,180,0,0,10,0,400,(diffMulti==0.5) ? 999:9999,0.3,200*diffMulti);
		unit2.setCenter(1,-5.6,-0.3);
		unitVec.push_back(unit2);
		Unit unit3(&nothing,0.03,4.8,-2,-7,90,180,0,0,10,0,400,(diffMulti==0.5) ? 999:9999,0.3,200*diffMulti);
		unit3.setCenter(-1,-5.6,-0.3);
		unitVec.push_back(unit3);
		Unit unit4(&nothing,0.03,4.8,-2,-7,90,180,0,0,10,0,400,(diffMulti==0.5) ? 999:9999,0.3,200*diffMulti);
		unit4.setCenter(0.7,-5.0,-1.1);
		unitVec.push_back(unit4);
		Unit unit5(&nothing,0.03,4.8,-2,-7,90,180,0,0,10,0,400,(diffMulti==0.5) ? 999:9999,0.3,200*diffMulti);
		unit5.setCenter(-0.7,-5.0,-1.1);
		unitVec.push_back(unit5);

		initUnits[6]=true;
	}
}

void battleSequence(){

	// render units
	switch(battleN){
	case 0:
		break;
	case 1:
		battle1();
		break;
	case 2:
		battle2();
		break;
	case 3:
		battle3();
		break;
	case 4:
		battle4();
		break;
	case 5:
		battle5();
		break;
	case 6:
		battleDS();
		break;
	case 7:
		gameBeat=true;
		break;
	}

	// loop through units
	if (loopUnits()){
		renderLaser();
		renderExplosion();
	}
	else
	{
		unitVec.clear();
		playerHP+=30;
		battleN++;
	}
}

void renderShield(){
	glPushAttrib(GL_LIGHTING_BIT | GL_CURRENT_BIT);
	glDisable(GL_LIGHTING);
	 glEnable( GL_BLEND );

	float col[] = {0,0,1,0.8};
	glPushMatrix();
				glTranslatef(-(float)(shipX-400)/200.0f,0,0); 
				glRotatef(-((mouseX-400)/400.0f)*30,0,1,0);
				glRotatef(-((mouseY-200)/200.0f)*10,0,0,1);
				glScalef(0.25,0.25,0.25);
				glColor4fv(col);  
				glutWireDodecahedron();
				
			glPopMatrix();
	glDisable(GL_BLEND);
	glEnable(GL_LIGHTING);
		glPopAttrib();
	}
void drawUnits(){
	glMatrixMode(GL_MODELVIEW);
	//
	if (sequence==5){
		int step = sceneN - 2321;
		enableLights();

		glPushMatrix();
		glRotatef(90.f,1.f,0.f,0.f);	
		glRotatef(220.f,0.f,1.f,0.f);
		glTranslatef( -2.5f+5.0f*step/350.0f, -1.2f+0.8*step/350.0f, -0.5+1.2*step/350.0f);

		glScalef(0.25f*(1.0f-step/400.0f),0.25f*(1.0f-step/400.0f),0.25f*(1.0f-step/400.0f));
		landspeeder.render();
		
		glPopMatrix();
		
		
		disableLights();
	}
	else if (sequence==3){
		int step = sceneN - 2615;
		enableLights();

		glPushMatrix();
		glRotatef(90.f,1.f,0.f,0.f);	
		glRotatef(180.f,0.f,1.f,0.f);
		//glTranslatef(loc[0],loc[1],loc[2]);
		
		//start pos
		glRotatef((-20.f+20.0f*step/184.0f),0.f,0.f,1.f);
		glTranslatef((-5.0f+6.0f*step/184.0f), (2.0f-2.0f*step/184.0f), (8.0f-3.0f*step/184.0f) );

		glScalef(0.5,0.5,0.5);
		glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);
		//glColor3d(0,0,1);
		landspeeder.render();
		glPopMatrix();

		disableLights();
	}
	else if (sequence==4){
		enableLights();

		glPushMatrix();
		glRotatef(90.f,1.f,0.f,0.f);	
		glRotatef(270.f,0.f,1.f,0.f);

		glTranslatef(0,0,(float)(shipX-400)/200.0f); 
		
		if (shipDX>0){
			glRotatef(shipDX,1.f,0.f,0.f);
			shipDX--;
		}else if (shipDX<0){
			glRotatef(shipDX,1.f,0.f,0.f);
			shipDX++;
		}
		glRotatef(-((mouseX-400)/400.0f)*30,0,1,0);
		glRotatef(-((mouseY-200)/200.0f)*10,0,0,1);
		glScalef(0.2,0.2,0.2);
		glGetFloatv(GL_MODELVIEW_MATRIX, fmModel);

		landspeeder.render();

		glPopMatrix();
		

		battleSequence();

		glPushMatrix();
		if (!gameOver){
		float pos[3] = {-1.5,0,-0.3};
		float col[4] = {0,1,0,1};
		char str[30]; 
		char hp[5];
		strcpy (str,"Player HP: ");
		itoa (playerHP,hp,10);
		strcat (str,hp);
		strcat (str,"/300");
		drawString3D(str, pos,col,GLUT_BITMAP_HELVETICA_12);

		float pos2[3] = {-1.47,0,-0.2};
		col[1]=0;col[2]=1;
		strcpy (str,"Shields Remaining: ");
		itoa (shieldLeft,hp,10);
		strcat (str,hp);
		drawString3D(str, pos2,col,GLUT_BITMAP_HELVETICA_12);

		float pos3[3] = {-1.45,0,-0.1};
		strcpy(str,"Difficulty: ");
		
		if (diffMulti==0.5)
			strcat (str,"Easy");
		else if (diffMulti==1)
			strcat (str,"Normal"); 
		else if (diffMulti==1.5)
			strcat (str,"Hard"); 
		else
			strcat (str,"Insane"); 
		
		drawString3D(str, pos3,col,GLUT_BITMAP_HELVETICA_12);

		if (useShield){
			
			if (shieldTimeRemaining>100){
				renderShield();
			} else if (shieldTimeRemaining%2){
				renderShield();
			}
		}

		if (drawBounds && devMode){
			glPushMatrix();
			glTranslatef(-(float)(shipX-400)/200.0f,0,0); 
			glutWireSphere(boundRadius,10,10);
			glPopMatrix();
		}

		}
		glPopMatrix();

		disableLights();
	}
}
// This function was provided by the CS175 HW3/HW4 solutions.
void render()
{
	// clear color and depth buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// apply the camera transformations
	cam.apply();
   // get projection matrix P
   glMatrixMode(GL_PROJECTION);
   glGetFloatv(GL_PROJECTION_MATRIX, fmProj);

   // get viewing matrix V
	glMatrixMode(GL_MODELVIEW);
   glGetFloatv(GL_MODELVIEW_MATRIX, fmView);

   glPushMatrix();

	// draw skyBox
      glDisable(GL_CULL_FACE);
      GLuint shaderProgramHandle = shaderProgramHandles[ SHADER_SKYBOX ]; 
      
      glUseProgram( shaderProgramHandle );

      GLuint fmProjHandle = glGetUniformLocation( shaderProgramHandle, "fmProj" );
      GLuint fmViewHandle = glGetUniformLocation( shaderProgramHandle, "fmView" );
      glUniformMatrix4fv( fmProjHandle, 1, false, fmProj );
      glUniformMatrix4fv( fmViewHandle, 1, false, fmView );


      glActiveTexture( GL_TEXTURE0 );
      glBindTexture( GL_TEXTURE_CUBE_MAP, cubeTextureHandle );
      GLint cubeMapHandle = glGetUniformLocation( shaderProgramHandle, "cubeMap" );
      glUniform1i( cubeMapHandle, 0);

      drawCube( 20.0 );
      glEnable(GL_CULL_FACE);
	  glPopMatrix();
	   glPushMatrix();
   drawScene();

   

    glPopMatrix();
	 glPushMatrix();
	drawUnits();
	 glPopMatrix();
   checkGLErrors();
}
// This function was provided by the CS175 HW3/HW4 solutions.
// ----------------------------------------------------------------------------------------------------

// GLUT CALLBACKS
// ----------------------------------------------------------------------------------------------------

// _____________________________________________________
//|														           |
//|	 reshape														  |
//|_____________________________________________________|
///
///  Whenever a window is resized, a "resize" event is
///  generated and GLUT is told to call this reshape
///  callback function to handle it appropriately.

void reshape(int w, int h)
{
   glViewport( 0, 0, w, h );
   cam.setAspectRatio( (float)w / (float)h );
}

// _____________________________________________________
//|														           |
//|	 display											           |
//|_____________________________________________________|
///
///  Whenever OpenGL requires a screen refresh
///  it will call display() to draw the scene.
///  We specify that this is the correct function
///  to call with the glutDisplayFunc() function
///  during initialization

// This function was provided by the CS175 HW3/HW4 solutions.
void display(void) {
	// perform OpenGL rendering
	render();

	// swap buffers
	glutSwapBuffers();
}

// _____________________________________________________
//|														           |
//|	 keyboard											        |
//|_____________________________________________________|
///
///  Whenever a key on the keyboard is pressed, 
///  a "keyboard" event is generated and GLUT is told 
///  to call this keyboard callback function to handle it
///  appropriately.
// This function was partially provided by the CS175 HW3/HW4 solutions.
void keyboard(unsigned char key, int x, int y) {
	switch (key) {
	case 27:
      {
		   exit(0);
		   break;
      }
   case 'c':
      {
         drawClouds = drawClouds?false:true;
         if ( drawClouds )
         {
            cout << "The earth is drawn with clouds." << endl;
         }
         else
         {
            cout << "The earth is drawn without clouds." << endl;
         }
         break;
      }
   case 'a':
	   if (moveable)
		{
		   if (shipX>50){
				shipX-=10;
				shipDX=-10;
				glutPostRedisplay();
		 }
	   }
		break;
   case 'd':
	   if (moveable)
		{
		 if (shipX<750){
				shipDX = 10;
				shipX+=10;
				glutPostRedisplay();
		   }
	   }
	   break;
   case 'b':
	   drawBounds = !drawBounds; break;
	case 'r':
		for (int i=1;i<=6;i++)
			initUnits[i]=false;
		gameOver=false; laserVec.clear();unitVec.clear();enemyLaserVec.clear(); expVec.clear(); playerHP=300;
		PlaySound(NULL, 0, 0);
		sceneN=2615; battleN = 0; shipX=400;
		break;
	case '+':
		if (devMode)
		{
			unitVec.clear(); initUnits[battleN++]=false;
		}
		break;
	case '1': 
		diffMulti=0.5; unitVec.clear(); initUnits[battleN]=false;
		break;
	case '2': 
		diffMulti=1.0; unitVec.clear(); initUnits[battleN]=false;
		break;
	case '3': 
		diffMulti=1.5; unitVec.clear(); initUnits[battleN]=false;
		break;
	case '4': 
		diffMulti=5.0; unitVec.clear(); initUnits[battleN]=false;
		break;
	case 's':
		if (moveable)
		{
			if (shieldLeft>0){
				shieldLeft--;
				useShield=true; 
				shieldTimeRemaining=shieldLag-1;
			}
		}	
		break;
	}
	// pitch
	if (devMode){
	if (key == 'i') cam.pitch( 2.0f );
	if (key == 'k') cam.pitch( -2.0f );
	// yaw
	if (key == 'j') cam.yaw( -2.0f );
	if (key == 'l') cam.yaw( 2.0f );
	// roll
	//if (key == 's') cam.roll( 1.0f );
	//if (key == 'f') cam.roll( -1.0f );	
	// zoom
	if (key == ',') cam.slide( 0.0f, 0.0f, -0.05f );
	if (key == '.') cam.slide( 0.0f, 0.0f, 0.05f );
	}
	glutPostRedisplay();
}


// pick method provided by Moritz!
bool pick(int x, int y)
{
   GLdouble  modelview[16], projection[16];
   GLint     viewport[4];
   glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
   glGetDoublev(GL_PROJECTION_MATRIX, projection);
   glGetIntegerv(GL_VIEWPORT, viewport);

   // read depth buffer value at (x, y_new)
   float  z;
   int    yNew = viewport[3] - y; // in OpenGL y is zero at the 'bottom'
   glReadPixels(x, yNew, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &z );

   // reverse projection to get 3D point
   gluUnProject(x, yNew, z, 
      modelview, 
      projection, 
      viewport, 
      &pos[0], &pos[1], &pos[2]);

   return false;
}

void fire(int x, int y){
	if (fireLag==0 && y<screenY*0.8){
		if (battleN!=6 && !explodeSound)
			PlaySound(L"Sounds/fire.wav", NULL, SND_FILENAME | SND_ASYNC);
		fireLag=10;
		pick(x,y);
		Laser laser(-(float)(shipX-400)/200.0f,0,0,pos[0]+(float)(shipX-400)/200.0f,pos[1],pos[2],false);
		//cout << pos[0] << " "<< pos[1] << " "<< pos[2] << "\n";
		laserVec.push_back(laser);
	}
}



// _____________________________________________________
//|														|
//|	 mouse											    |
//|_____________________________________________________|
///
///  Whenever a mouse button is clicked, a "mouse" event 
///  is generated and GLUT calls this mouse callback to 
///  handle it appropriately.
// This function was partially provided by the CS175 HW3/HW4 solutions.
void mouse(int button, int state, int x, int y)
{
	if (moveable)
	{
	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		mousefire = true;
		mouseX = x;
		mouseY = y;
	}
	else if(button == GLUT_LEFT_BUTTON && state == GLUT_UP)
	{
		mousefire=false;
	}
	if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		mouseX = x;
		mouseY = y;
	}
	else if(button == GLUT_RIGHT_BUTTON && state == GLUT_UP)
	{
		
	}
   glutPostRedisplay();
	}
}

// _____________________________________________________
//|														           |
//|	 motion											           |
//|_____________________________________________________|
///
///  Moving the mouse generates a "motion" event that can be 
///  handled in this motion callback function. Using this
///  in combination with the "mouse" callback will allow us
///  to interact with the scene using the mouse.
// This function was partially provided by the CS175 HW3/HW4 solutions.
void motion(int x, int y)
{
	mouseX=x;
	mouseY=y;

	glutPostRedisplay();
}

void activeMotion(int x, int y){
	if (moveable)
	{
	mouseX=x;
	mouseY=y;
	if (fireLag==0&& mousefire)
		fire(x,y);
	glutPostRedisplay();
	}
}

void resetCam(){
	cam.set( camInitCenter[0], camInitCenter[1], camInitCenter[2], 
				camInitLook[0], camInitLook[1], camInitLook[2],
				camInitUp[0], camInitUp[1], camInitUp[2] );
}

void moveLaser(int i){
	for (int i=laserVec.size()-1;i>=0;i--) {
		laserVec[i].Move();
		
		if (laserVec[i].loc[1]<-2 && laserVec[i].loc[2]>-2){
			// collision check here
			for (int j=0,n=unitVec.size();j<n;j++){
				if (unitVec[j].renderState==100 && unitVec[j].testCollision(laserVec[i].loc[0],laserVec[i].loc[1],laserVec[i].loc[2])){
					explosion(laserVec[i].loc[0],laserVec[i].loc[1],laserVec[i].loc[2],0);
					laserVec.erase(laserVec.begin()+i);
				}
			}
		}
		
		if (laserVec[i].loc[1]<-10||laserVec[i].loc[2]<-2)
			laserVec.erase(laserVec.begin()+i);
	}

	for (int i=enemyLaserVec.size()-1;i>=0;i--) {
		enemyLaserVec[i].enemyMove();
		
		if (enemyLaserVec[i].loc[1]>-2){

			if (enemyLaserVec[i].loc[1]>0)
			{
				enemyLaserVec.erase(enemyLaserVec.begin()+i);
			}
			else
			{
				// collision check with landspeeder here
				float distance = sqrt(pow((float)(shipX-400)/200.0f-enemyLaserVec[i].loc[0],2)+pow(0-enemyLaserVec[i].loc[1],2)+pow(0-enemyLaserVec[i].loc[2],2));
				if (distance<=boundRadius){
					if (!useShield){
						playerHP-=(boundRadius-distance)/boundRadius*50;
						explosion(-enemyLaserVec[i].loc[0],enemyLaserVec[i].loc[1],enemyLaserVec[i].loc[2],1);
					}
					enemyLaserVec.erase(enemyLaserVec.begin()+i);
					if (playerHP<=0)
						gameOver=true;
				}
			}
		}
		
	
	}
	
	glutTimerFunc( delay, moveLaser, 0);
}

void fireTimer(int i){
	if (fireLag>0)
		fireLag--;

	if (mousefire && fireLag==0)
		fire(mouseX,mouseY);

	glutTimerFunc( delay, fireTimer, 0);
}

void shieldTimer(int i){
	if (useShield){
		shieldTimeRemaining--;
	}
	if (shieldTimeRemaining ==0){
		useShield=false;
	}
	glutTimerFunc( delay, shieldTimer, 0);
}

void sceneTimer(int i){
	
	if (sceneN==0){
		PlaySound(L"Sounds/sw3.wav", NULL, SND_FILENAME | SND_ASYNC);
		sequence = 1;
	} else if (sceneN>0){ 
		
		if (sceneN<200){
			cam.slide( 0.0f, 0.0f, 0.02f );
		} else if (sceneN<350){
			cam.slide( 0.0f, 0.0f, 0.05f );
		} else if (sceneN==351){
			resetCam(); sequence = 2;
		} else if (sceneN<2220) {
			cam.slide( 0.0f, -0.0003f, 0.0015f );
		} else if (sceneN<2320){
			cam.pitch( -0.2f );
		} else if (sceneN==2321){
			 resetCam(); sequence = 5;
			 sceneTrans1();
			 cam.slide(0.0f,-0.555f,0.0f);
			 cam.pitch(-20.0f);
		} else if (sceneN == 2400 ){
			PlaySound(L"Sounds/flyby.wav", NULL, SND_FILENAME | SND_ASYNC);
		} else if (sceneN>2435 && sceneN<2530){
			cam.pitch(0.1f);
			cam.yaw(-0.32f);
		}else if (sceneN==2615){
			moveable=false;
			PlaySound(L"Sounds/flyby.wav", NULL, SND_FILENAME | SND_ASYNC);
			resetCam(); sequence = 3;
			cam.slide( 0.0f,0.0f, 8.0f );
			cam.yaw(40.f);
			cam.pitch(15.0f);
			// fly in game scene
		}else if (sceneN>2645 && sceneN<2799){
			cam.yaw(-0.2f);
			cam.pitch(-0.12f);
			cam.roll(0.038f);
			cam.slide( 0.0f,0.0075f, 0.001f );
			// fly in game scene
		}else if (sceneN==2800){
			resetCam(); sequence =4; battleN = 1; moveable=true;
			cam.slide(0,2,1);
			cam.pitch(-28.0f);
			// actual game scene
		} else if (sceneN>2900){ 
			// fly out
		} else if (sceneN==3000){
			sequence = 20;
			// game over!
		}
	
	}

	//cout << sceneN << " "; 

	if (gameBeat){
		PlaySound(L"Sounds/victory.wav", NULL, SND_FILENAME | SND_ASYNC);
		sequence=20; laserVec.clear();unitVec.clear();enemyLaserVec.clear(); gameBeat=false; moveable=false; mousefire=false;
		resetCam();
	}

	if (sceneN!=2801)
		sceneN++;

	if (sceneN<3000){
		glutTimerFunc( delay, sceneTimer, 0);
	}
	
	glutPostRedisplay();
}

// ----------------------------------------------------------------------------------------------------


// INITIALIZATIONS
// ----------------------------------------------------------------------------------------------------
// This function was provided by the CS175 HW3/HW4 solutions.
void initsGLUTState( )
{
	// use RGBA pixel channels, double buffering, and depth buffering
	glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH );

	// choose initial window size 
	glutInitWindowSize( INIT_SCREEN_WIDTH, INIT_SCREEN_HEIGHT );

	// create a window
	glutCreateWindow( "Star Wars Final Project" );

	// register the callback functions
	glutDisplayFunc( display );
	glutReshapeFunc( reshape );
	glutKeyboardFunc( keyboard );
	glutMouseFunc( mouse );
	glutMotionFunc( activeMotion );
	glutPassiveMotionFunc( motion );

	glutTimerFunc( 50, sceneTimer, 0);
	glutTimerFunc( 50, fireTimer, 0);
	glutTimerFunc( 50, moveLaser, 0);
	glutTimerFunc( 50, shieldTimer, 0);
}
// This function was provided by the CS175 HW3/HW4 solutions.
void initsGLState()
{
   const GLubyte *str;
   str = glGetString (GL_VERSION);
   cout << str << endl;

	// set the clear color to black
	glClearColor( 0.0, 0.0, 0.0, 1.0 );
	glClearDepth(0.0);
	glCullFace(GL_BACK);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_GREATER);

   // init camera parameters
   cam.setFov( FOV );
	cam.setNearPlane( NEAR_PLANE );
	cam.setFarPlane( FAR_PLANE );
	cam.set( camInitCenter[0], camInitCenter[1], camInitCenter[2], 
				camInitLook[0], camInitLook[1], camInitLook[2],
				camInitUp[0], camInitUp[1], camInitUp[2] );

	checkGLErrors();
}
// This function was provided by the CS175 HW3/HW4 solutions.
void initGLSLState()
{
   const GLubyte *str;
   str = glGetString (GL_SHADING_LANGUAGE_VERSION);
   cout << str << endl;
   for ( int shaderIndex = 0; shaderIndex < NUM_SHADERS; ++shaderIndex )
   {
      GLuint shaderProgramHandle = compileShaders( shaderProgramFileNames[ shaderIndex ][ 0 ], shaderProgramFileNames[ shaderIndex ][ 1 ] );
      shaderProgramHandles[ shaderIndex ] = shaderProgramHandle;
   }
   
   loadTextures();
   loadCubeMap();
   createTerrain();

   landspeeder.loadOBJ("LandSpeeder.obj");
   trifighter.loadOBJ("trifighter.obj");
   deathStar.loadOBJ("deathstar.obj");
   enemy.loadOBJ("enemy.obj");
   yt1300.loadOBJ("yt1300.obj");
   jedi.loadOBJ("jedi.obj");

   checkGLErrors();
}
// This function was provided by the CS175 HW3/HW4 solutions.
void cleanGLSLState()
{
   for ( int shaderIndex = 0; shaderIndex < NUM_SHADERS; shaderIndex++ )
   {
      glDeleteProgram( shaderProgramHandles[ shaderIndex ] );
   }
   deleteTextures();
}

// ----------------------------------------------------------------------------------------------------

// MAIN
// ----------------------------------------------------------------------------------------------------
// This function was provided by the CS175 HW3/HW4 solutions.
int main(int argc, char **argv) 
{
	try {
		// initialize GLUT based on command-line arguments
		glutInit(&argc, argv); 

		// initialize GLUT states
		initsGLUTState();

		// initialize GLEW
		glewInit();

		// check if at least OpenGL version 2.0 is supported
		if (glewIsSupported("GL_VERSION_2_0"))
			printf("Ready for OpenGL 2.0\n");
		else {
			throw runtime_error("OpenGL 2.0 not supported\n");
		}

		// initialize OpenGL states
		initsGLState();

      // initialize GLSL states (shaders)
      initGLSLState();

		// enter the GLUT main (event) loop
		glutMainLoop();

      // cleanup GLSL states (shaders)
      cleanGLSLState();

		return 0;
	}
	catch (exception& e) {
		cout << "Exception caught: " << e.what() << endl;
		return -1;
	}
}

// ----------------------------------------------------------------------------------------------------