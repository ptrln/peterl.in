// This file was provided by the CS175 HW3/HW4 solutions.
#include <assert.h>

#include "model3d.h"
#include "objLoader.h"
#include "material.h"
#include "GLTools.h"

// fixme: no need to keep loader around

void checkGLErrors(const char *msg="") {
	const GLenum errCode = glGetError();      // check for errors
	if (errCode != GL_NO_ERROR) 
		fprintf(stderr,"Error (%s) : %s\n",msg,gluErrorString(errCode));
}

Model3D::~Model3D(){
	cleanup();
}

void Model3D::cleanup(){
	if(geometry){
		for(int i=0; i<nm; i++){
			for(int j=0; j<2; j++)
				delete geometry[i][j];
			delete [] geometry[i];
		}
		delete [] geometry;
	}
	if(materials){
		for(int i=0; i<nm; i++)
			delete materials[i];
		delete [] materials;
	}

	ready=false;
}

void Model3D::render(){
	int vertsPerFace[2]={3,4};
	for(int i=0; i<nm; i++){
		materials[i]->activate();
		geometry[i][0]->render();
		geometry[i][1]->render();
		materials[i]->deactivate();
	}
}

void Model3D::loadOBJ(const char *filename){
	// cleanup any existing data
	cleanup();

	// load OBJ model data
	loader=new objLoader();
	int ok=loader->load((char*)filename);
	if(!ok)
		return;

	// create material objects 
	nm=loader->materialCount;
	materials=new Material*[nm];
	for(int i=0; i<loader->materialCount; i++)
		materials[i]=new Material(loader->materialList[i]);
	
	// construct geometry data, 1 list per material, per face type (tris, quads)
	geometry=new GeometryList**[nm];
	int vertsPerFace[2]={3,4};// fixme: hardcoded
	for(int i=0; i<nm; i++){
		geometry[i]=new GeometryList*[2];
		for(int j=0; j<2; j++){
			geometry[i][j]=new GeometryList(loader,i,vertsPerFace[j],materials[i]);
		}
	}
	
	ready=true;
}

GeometryList::GeometryList() :  materialIndex(-1), vertsPerFace(0), numFaces(0), 
	hasTexture(false),hasColor(false){}


GeometryList::GeometryList(objLoader *loader, int materialIndex, int vertsPerFace, Material *material) :
  materialIndex(materialIndex), vertsPerFace(vertsPerFace), numFaces(0),hasTexture(false),hasColor(false){

	assert(vertsPerFace==3 || vertsPerFace==4);
	hasTexture= false;//strlen(loader->materialList[materialIndex]->texture_filename)>0; // TEMP

	// count faces
	for(int i=0; i<loader->faceCount; i++){
		obj_face *face=loader->faceList[i];	
		if(face->material_index==materialIndex && face->vertex_count==vertsPerFace)
			numFaces++;
	}

	// allocate space
	vertexData=new Point[numFaces*vertsPerFace];
	normalData=new Vector[numFaces*vertsPerFace];
	texCoordData=(hasTexture) ? new Vector[numFaces*vertsPerFace] : NULL;
	// store, duplicating as necessary
	int j=0;
	for(int i=0; i<loader->faceCount; i++){
		obj_face *face=loader->faceList[i];	
		if(face->material_index==materialIndex && face->vertex_count==vertsPerFace){
			for(int k=0; k<vertsPerFace; k++,j++){
				for(int c=0; c<3; c++){
					vertexData[j][c]=(float)loader->vertexList[face->vertex_index[k]]->e[c];
					normalData[j][c]=(float)loader->normalList[face->normal_index[k]]->e[c];
					if(hasTexture)
						texCoordData[j][c]=min(1.f,max(0.f,(float)loader->textureList[face->texture_index[k]]->e[c]));
				}
			}
		}
	}
}



void GeometryList::render(){
	GLenum faceType=(vertsPerFace==3) ? GL_TRIANGLES : GL_QUADS;

	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
	if(hasTexture){
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		glTexCoordPointer(2,GL_FLOAT,4,texCoordData);
	}
	if(hasColor){
		glColorMaterial(GL_FRONT_AND_BACK,GL_DIFFUSE);
		glEnable(GL_COLOR_MATERIAL);
		glEnableClientState(GL_COLOR_ARRAY);
		glColorPointer(3,GL_FLOAT,0,colorData);
	}
	glNormalPointer(GL_FLOAT,0,normalData);
	glVertexPointer(3,GL_FLOAT,0,vertexData);

	//glTranslatef(0,0,-1);
	
	glDrawArrays(faceType,0,numFaces*vertsPerFace);
	
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisable(GL_COLOR_MATERIAL);
}

GeometryList::~GeometryList(){
	// fixme: delete opengl vertex array data

	delete [] vertexData;
	delete [] texCoordData;
	delete [] normalData;

}
