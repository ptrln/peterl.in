// This file was provided by the CS175 HW3/HW4 solutions.
#define GLEW_STATIC
#include <GL/glew.h>
#ifdef __MAC__
#	include <GLUT/glut.h>
#else
#  define FREEGLUT_STATIC
#  include <GL/glut.h>
#endif

#include "GLTools.h"

#include "shaders.h"
#include "material.h"
#include "obj_parser.h"

Material::Material(obj_material *objMaterial) : hasTex(false){

	// grab phong parameters
	for(int i=0; i<3; i++){
		ambient[i]=(float)objMaterial->amb[i]+0.1f;// TEMP: +0.1f, only while texture is disabled
		diffuse[i]=(float)objMaterial->diff[i]+0.1f;
		specular[i]=(float)objMaterial->spec[i]+0.1f;
	}
	specPower=(float)objMaterial->shiny;
	trans=(float)objMaterial->trans;

	// read texture image and load texture onto GPU
	if(objMaterial->texture_filename){
		hasTex=true;
		// read data from disk
		GLbyte *texData=gltReadTGABits(objMaterial->texture_filename,
			&texWidth,&texHeight,&texComp,&texFormat);
		// setup texture on GPU
		glGenTextures(1,&texHandle);
		glBindTexture(GL_TEXTURE_2D,texHandle);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
		// read texture data onto GPU
		glTexImage2D(GL_TEXTURE_2D,0,texComp,texWidth,texHeight,0,texFormat,GL_UNSIGNED_BYTE,texData);
		free(texData);
	}
}

Material::Material(const char *textureFilename){

	// set default phong parameters
	for(int i=0; i<3; i++){
		ambient[i]=0.f;
		diffuse[i]=0.f;
		specular[i]=0.f;
	}
	specPower=0.f;
	trans=0.f;

	// read texture image and load texture onto GPU
	hasTex=true;
	// read data from disk
	GLbyte *texData=gltReadTGABits(textureFilename,
		&texWidth,&texHeight,&texComp,&texFormat);
	// setup texture on GPU
	glGenTextures(1,&texHandle);
	glBindTexture(GL_TEXTURE_2D,texHandle);
	// debug: make sure these settings are reasonable
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
	// read texture data onto GPU
	glTexImage2D(GL_TEXTURE_2D,0,texComp,texWidth,texHeight,0,texFormat,GL_UNSIGNED_BYTE,texData);
	free(texData);

}

Material::~Material(){
	if(hasTex){
		// fixme: release texture memory on GPU
	}
}


void Material::activate(){
	
	glUseProgram(0 );
	
	if(hasTex){
		glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
		glActiveTexture(MATERIAL_TEXTURE_UNIT);
		glBindTexture(GL_TEXTURE_2D,texHandle);
		glEnable(GL_TEXTURE_2D);
	}else
		glDisable(GL_TEXTURE_2D);

	// setup material colors
	glPushAttrib(GL_LIGHTING_BIT);
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,ambient);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,diffuse);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,specular);
	glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,specPower);
		
	// setup blending
	glPushAttrib(GL_ENABLE_BIT);
	if(trans<1){
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	}else
		glDisable(GL_BLEND);
}

void Material::deactivate(){
	glPopAttrib();
	glPopAttrib();
	glUseProgram(0);
	glDisable(GL_TEXTURE_2D);
}